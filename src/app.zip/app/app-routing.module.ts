import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './homepage/homepage.component';
import { UserComponent } from './user/user.component';
import { ReportsComponent } from './reports/reports.component';
import { DashboardComponent } from './dashboard/dashboard.component';


const routes: Routes = [
  // {path: 'homepage', 
  //   component: HomepageComponent
  // },
  {path: 'user', 
    component: UserComponent
  }
  // {path: 'reports', 
  //   component: ReportsComponent
  // },
  // {path: 'dashboard',
  //   component: DashboardComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
