export class Reports{
    id:Number;
    username:String;
    game:String;
    report:String;
    status:String;
    datereported:String;
    solution:String;
    datesolved:String;
}