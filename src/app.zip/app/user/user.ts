export class Users{
    id:Number;
    name:String;
    age:Number;
    address:String;
    gender:String;
    username:String;
    password:String;
}